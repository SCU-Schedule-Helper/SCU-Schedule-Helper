var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { fetchWithAuth } from "./authorization.js";
import { PROD_EVALS_ENDPOINT, PROD_NAME_MAPPINGS_ENDPOINT, } from "./constants.js";
/**
 * Fetches the evals object from the server, then decodes, decompresses, and stores it in local storage.
 * @returns {Promise<void>}
 */
export function downloadEvals() {
    return __awaiter(this, void 0, void 0, function* () {
        const evalsLastModifiedDate = (yield chrome.storage.local.get("evalsLastModifiedDate")).evalsLastModifiedDate;
        const evalsResponse = yield fetchWithAuth(PROD_EVALS_ENDPOINT, {
            headers: evalsLastModifiedDate
                ? {
                    "If-Modified-Since": evalsLastModifiedDate,
                }
                : {},
        });
        if (!evalsResponse || !evalsResponse.ok || evalsResponse.status === 304) {
            yield chrome.storage.local.set({
                isDownloadingEvals: false,
            });
            return;
        }
        const evalsObject = yield evalsResponse.json();
        const evals = yield decodeAndDecompress(evalsObject.data);
        yield chrome.storage.local.set({
            evals,
            evalsLastModifiedDate: evalsResponse.headers.get("last-modified"),
            isDownloadingEvals: false,
        });
    });
}
export function downloadProfessorNameMappings() {
    return __awaiter(this, void 0, void 0, function* () {
        const mappingsLastModifiedDate = (yield chrome.storage.local.get("mappingsLastModifiedDate")).mappingsLastModifiedDate;
        const response = yield fetchWithAuth(PROD_NAME_MAPPINGS_ENDPOINT, {
            headers: mappingsLastModifiedDate
                ? {
                    "If-Modified-Since": mappingsLastModifiedDate,
                }
                : {},
        });
        if (!response || !response.ok || response.status === 304) {
            return;
        }
        const mappingsResponse = yield response.json();
        yield chrome.storage.local.set({
            professorNameMappings: mappingsResponse.data,
            mappingsLastModifiedDate: response.headers.get("last-modified"),
        });
    });
}
function decodeAndDecompress(base64EncodedGzippedData) {
    return __awaiter(this, void 0, void 0, function* () {
        const binaryString = atob(base64EncodedGzippedData);
        const binaryData = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) {
            binaryData[i] = binaryString.charCodeAt(i);
        }
        const body = new Response(binaryData).body;
        if (!body)
            throw new Error("Failed to create response body for decompression");
        const decompressedStream = body.pipeThrough(new DecompressionStream("gzip"));
        const decompressedText = yield new Response(decompressedStream).text();
        const jsonData = JSON.parse(decompressedText);
        return jsonData;
    });
}
