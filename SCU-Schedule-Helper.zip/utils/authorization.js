var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
/// <reference lib="webworker" />
import { subscribe } from "./notifications.js";
import { PROD_AUTH_TOKEN_ENDPOINT, PROD_USER_ENDPOINT, WEB_AUTH_CLIENT_ID } from "./constants.js";
import { downloadEvals, downloadProfessorNameMappings, } from "./evalsAndMappings.js";
import { refreshUserData } from "./user.js";
const sizePattern = /(.*)=s\d+-c/;
/**
 * Triggers the OAuth flow to sign in the user, and creates an account for the user, using the OAuth info provided by Google.
 * @returns {Promise<string | null>} Error message or null if successful
 */
export function signIn() {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        let oAuthToken;
        try {
            const oAuthUrl = new URL("https://accounts.google.com/o/oauth2/v2/auth");
            oAuthUrl.searchParams.set("client_id", WEB_AUTH_CLIENT_ID);
            oAuthUrl.searchParams.set("redirect_uri", chrome.identity.getRedirectURL());
            oAuthUrl.searchParams.set("response_type", "token");
            oAuthUrl.searchParams.set("scope", "https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email");
            oAuthUrl.searchParams.set("prompt", "select_account");
            const responseUrl = yield chrome.identity.launchWebAuthFlow({
                url: oAuthUrl.toString(),
                interactive: true,
            });
            if (!responseUrl) {
                return "Authorization cancelled.";
            }
            const urlParams = new URLSearchParams(responseUrl.split("#")[1]);
            oAuthToken = urlParams.get("access_token");
            if (!oAuthToken) {
                return "Failed to get access token.";
            }
        }
        catch (error) {
            console.error("OAuth error:", error);
            return "Authorization cancelled.";
        }
        let subscription = (yield self.registration.pushManager.getSubscription()) || null;
        try {
            let permission = 'default';
            if (typeof self !== 'undefined' && self.registration) {
                permission = 'granted';
            }
            if (permission === 'granted') {
                const sub = yield subscribe();
                if (sub)
                    subscription = sub;
            }
            else {
                console.warn("Notification permission denied, continuing without push notifications");
            }
        }
        catch (error) {
            console.warn("Push notifications not available");
        }
        const response = yield fetch(PROD_AUTH_TOKEN_ENDPOINT, {
            method: "GET",
            headers: {
                Authorization: `OAuth ${oAuthToken}`,
            },
        });
        const data = yield response.json();
        if (response.status !== 200) {
            chrome.identity.removeCachedAuthToken({
                token: oAuthToken,
            });
            yield fetch(`https://oauth2.googleapis.com/revoke?token=${encodeURIComponent(oAuthToken || "")}`, {
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                method: "POST",
            });
            return `${data.message}`;
        }
        yield chrome.storage.local.set({
            isDownloadingEvals: true,
        });
        yield chrome.storage.sync.set({
            accessToken: data.accessToken,
            accessTokenExpirationDate: data.accessTokenExpirationDate,
            refreshToken: data.refreshToken,
        });
        // Start eval download in background.
        downloadEvals();
        downloadProfessorNameMappings();
        if (data.oAuthInfo.photoUrl.match(sizePattern)) {
            data.oAuthInfo.photoUrl = data.oAuthInfo.photoUrl.replace(sizePattern, "$1=s256-c");
        }
        const createdUser = yield fetch(PROD_USER_ENDPOINT, {
            method: "POST",
            headers: {
                Authorization: "Bearer " + data.accessToken,
            },
            body: JSON.stringify({
                name: data.oAuthInfo.name,
                photoUrl: data.oAuthInfo.photoUrl,
                subscription: JSON.stringify(subscription !== null && subscription !== void 0 ? subscription : undefined),
            }),
        });
        const createdUserData = yield createdUser.json();
        if (createdUser.status === 400 &&
            createdUserData.message === "You already have an account.") {
            const updateError = yield updateSubscriptionAndRefreshUserData(JSON.stringify(subscription !== null && subscription !== void 0 ? subscription : undefined));
            if (!updateError) {
                if (chrome.runtime.setUninstallURL) {
                    const userId = ((_a = (yield chrome.storage.local.get("userInfo")).userInfo) === null || _a === void 0 ? void 0 : _a.id) ||
                        "unknown";
                    yield chrome.runtime.setUninstallURL(`https://scu-schedule-helper.me/uninstall?u=${userId}&sub=${encodeURIComponent((subscription === null || subscription === void 0 ? void 0 : subscription.endpoint) || "")}`);
                }
            }
            return updateError;
        }
        else if (!createdUser.ok) {
            return `Error creating account. ${createdUserData.message || 'Unknown error.'}`;
        }
        yield chrome.storage.local.set({
            userInfo: {
                id: createdUserData.id,
                name: createdUserData.name,
                photoUrl: createdUserData.photoUrl,
                preferences: createdUserData.preferences,
                coursesTaken: createdUserData.coursesTaken,
                interestedSections: createdUserData.interestedSections,
            },
            friends: {},
            friendRequestsIn: {},
            friendRequestsOut: {},
            friendCoursesTaken: {},
            friendInterestedSections: {},
        });
        chrome.runtime.setUninstallURL(`https://scu-schedule-helper.me/uninstall?u=${createdUserData.id}&sub=${encodeURIComponent((subscription === null || subscription === void 0 ? void 0 : subscription.endpoint) || "")}`);
        return null;
    });
}
export function updateSubscriptionAndRefreshUserData(subscription) {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetchWithAuth(`${PROD_USER_ENDPOINT}`, {
            method: "PUT",
            body: JSON.stringify({
                personal: {
                    subscriptions: [subscription],
                },
            }),
        });
        if (!response) {
            return "Unknown error updating account. Please try again later.";
        }
        if (!response.ok) {
            const data = yield response.json();
            return `Error updating account: ${data.message}`;
        }
        return yield refreshUserData();
    });
}
/**
 * Signs out the user by clearing all local and sync storage.
 * Leaves the user's preferences in tact.
 */
export function signOut() {
    return __awaiter(this, arguments, void 0, function* (sendNotification = false) {
        var _a;
        const currentUserInfo = ((_a = (yield chrome.storage.local.get("userInfo"))) === null || _a === void 0 ? void 0 : _a.userInfo) || {
            coursesTaken: [],
            interestedSections: [],
            preferences: {
                scoreWeighting: {
                    scuEvals: 50,
                    rmp: 50,
                },
                preferredSectionTimeRange: {
                    startHour: 6,
                    startMinute: 0,
                    endHour: 20,
                    endMinute: 0,
                },
            },
        };
        delete currentUserInfo.id;
        delete currentUserInfo.email;
        delete currentUserInfo.name;
        delete currentUserInfo.photoUrl;
        delete currentUserInfo.subscriptions;
        delete currentUserInfo.interestedSections;
        delete currentUserInfo.coursesTaken;
        yield chrome.storage.local.clear();
        yield chrome.storage.sync.clear();
        yield chrome.storage.local.set({
            userInfo: currentUserInfo,
        });
        if (sendNotification) {
            chrome.notifications.create({
                type: "basic",
                iconUrl: "/images/icon-128.png",
                title: "Login Expired",
                message: "You have been signed out of SCU Schedule Helper.",
            });
        }
    });
}
export function getCalendarOAuthToken() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const responseUrl = yield chrome.identity.launchWebAuthFlow({
                url: `https://accounts.google.com/o/oauth2/v2/auth?client_id=${WEB_AUTH_CLIENT_ID}&redirect_uri=${chrome.identity.getRedirectURL()}&response_type=token&scope=https://www.googleapis.com/auth/calendar.events&prompt=select_account`,
                interactive: true,
            });
            if (!responseUrl) {
                return null;
            }
            const urlParams = new URLSearchParams(responseUrl.split("#")[1]);
            const accessToken = urlParams.get("access_token");
            return accessToken;
        }
        catch (error) {
            console.error("Error getting calendar OAuth token:", error);
            return null;
        }
    });
}
/**
 * Fetch a URL with the user's access token.
 * @param {*} endpoint The URL to fetch.
 * @param {*} requestInit The request object to pass to fetch.
 * @param {*} retries Number of times to retry the request if it fails with a 401.
 * @returns {Promise<Response | null>} The response object from the fetch.
 */
export function fetchWithAuth(endpoint_1) {
    return __awaiter(this, arguments, void 0, function* (endpoint, requestInit = {}, retries = 1) {
        const accessTokenData = yield chrome.storage.sync.get([
            "accessToken",
            "accessTokenExpirationDate",
        ]);
        if (!accessTokenData.accessToken ||
            !accessTokenData.accessTokenExpirationDate ||
            new Date(accessTokenData.accessTokenExpirationDate) < new Date()) {
            accessTokenData.accessToken = yield refreshAccessToken();
        }
        if (!accessTokenData.accessToken) {
            return null;
        }
        if (!requestInit.headers) {
            requestInit.headers = {};
        }
        // Ensure headers is a string-to-string map before setting Authorization
        requestInit.headers["Authorization"] = `Bearer ${accessTokenData.accessToken}`;
        const response = yield fetch(endpoint, Object.assign({}, requestInit));
        if (response.status === 401 && retries > 0) {
            yield refreshAccessToken();
            return fetchWithAuth(endpoint, requestInit, retries - 1);
        }
        return response;
    });
}
function refreshAccessToken() {
    return __awaiter(this, void 0, void 0, function* () {
        const refreshTokenData = yield chrome.storage.sync.get("refreshToken");
        if (!refreshTokenData.refreshToken) {
            return null;
        }
        const response = yield fetch(PROD_AUTH_TOKEN_ENDPOINT, {
            method: "GET",
            headers: {
                Authorization: `Bearer ${refreshTokenData.refreshToken}`,
            },
        });
        const data = yield response.json();
        if (response.status !== 200) {
            console.error("Error refreshing access token:", data.message);
            yield signOut(true);
            return null;
        }
        yield chrome.storage.sync.set({
            accessToken: data.accessToken,
            accessTokenExpirationDate: data.accessTokenExpirationDate,
        });
        return data.accessToken;
    });
}
