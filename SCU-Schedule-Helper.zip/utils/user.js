var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { COURSE_CODE_PATTERN, COURSE_TAKEN_PATTERN, INTERESTED_SECTION_PATTERN, PROD_USER_ENDPOINT, WORKDAY_COURSE_HISTORY_URL, WORKDAY_CURRENT_COURSES_URL, } from "./constants.js";
import { fetchWithAuth, signOut } from "./authorization.js";
export function refreshUserData() {
    return __awaiter(this, arguments, void 0, function* (items = []) {
        const itemsQuery = items.length > 0 ? `?items=${items.join(",")}` : "";
        const response = yield fetchWithAuth(`${PROD_USER_ENDPOINT}/me${itemsQuery}`);
        if (!response) {
            return "Unknown error fetching user data. Please try again later.";
        }
        let data = yield response.json();
        if (!response.ok) {
            data = data;
            return `Error fetching user data: ${data.message}`;
        }
        data = data;
        if (items.includes("friends") || items.length === 0) {
            const friends = {};
            yield chrome.storage.local.set({
                friendCoursesTaken: {},
                friendInterestedSections: {},
            });
            for (const friendObj of data.friends) {
                friends[friendObj.id] = friendObj;
                yield updateFriendCourseAndSectionIndexes(friendObj.id, friendObj.coursesTaken, friendObj.interestedSections);
            }
            yield chrome.storage.local.set({
                friends,
            });
        }
        if (items.includes("friendRequests") || items.length === 0) {
            const friendRequestsIn = {};
            const friendRequestsOut = {};
            for (const friendReqObj of data.friendRequests) {
                if (friendReqObj.type === "incoming") {
                    friendRequestsIn[friendReqObj.id] = friendReqObj;
                }
                if (friendReqObj.type === "outgoing") {
                    friendRequestsOut[friendReqObj.id] = friendReqObj;
                }
            }
            yield chrome.storage.local.set({
                friendRequestsIn,
                friendRequestsOut,
            });
        }
        const currentUserInfo = (yield chrome.storage.local.get("userInfo")).userInfo || {};
        if (items.includes("personal") || items.length === 0) {
            currentUserInfo.id = data.id;
            currentUserInfo.name = data.name;
            currentUserInfo.photoUrl = data.photoUrl;
        }
        if (items.includes("preferences") || items.length === 0) {
            currentUserInfo.preferences = data.preferences;
        }
        if (items.includes("coursesTaken") || items.length === 0) {
            currentUserInfo.coursesTaken = data.coursesTaken;
        }
        if (items.includes("interestedSections") || items.length === 0) {
            currentUserInfo.interestedSections = data.interestedSections;
        }
        yield chrome.storage.local.set({
            userInfo: Object.assign({}, currentUserInfo),
        });
        return null;
    });
}
export function updateUser(updateItems_1) {
    return __awaiter(this, arguments, void 0, function* (updateItems, allowLocalOnly = false) {
        const response = yield fetchWithAuth(PROD_USER_ENDPOINT, {
            method: "PUT",
            body: JSON.stringify(updateItems),
        });
        if (!response && !allowLocalOnly) {
            return {
                message: "Error updating user data (you may have been signed out).",
                ok: false,
            };
        }
        const data = (yield (response === null || response === void 0 ? void 0 : response.json())) || {};
        if (response && !response.ok) {
            return {
                message: `${data.message || "Unknown error updating user data."}`,
                ok: false,
            };
        }
        const errorUpdatingLocalCache = yield updateLocalCache(updateItems);
        if (errorUpdatingLocalCache) {
            return {
                message: errorUpdatingLocalCache,
                ok: false,
            };
        }
        return Object.assign(Object.assign({ message: "" }, data), { ok: true });
    });
}
function updateLocalCache(updateItems) {
    return __awaiter(this, void 0, void 0, function* () {
        const userInfo = (yield chrome.storage.local.get("userInfo")).userInfo || {};
        if (updateItems.personal) {
            if (updateItems.personal.name)
                userInfo.name = updateItems.personal.name;
            if (updateItems.personal.photoUrl === "default")
                userInfo.photoUrl =
                    "https://scu-schedule-helper.s3.us-west-1.amazonaws.com/default-avatar.jpg";
            if (updateItems.personal.photo) {
                userInfo.photoUrl = getS3PhotoUrl(userInfo.id);
            }
        }
        if (updateItems.preferences) {
            userInfo.preferences = Object.assign(Object.assign({}, (userInfo.preferences || {})), updateItems.preferences);
        }
        if (updateItems.coursesTaken) {
            userInfo.coursesTaken = userInfo.coursesTaken.concat(updateItems.coursesTaken.add);
            const coursesTaken = new Set(userInfo.coursesTaken);
            if (updateItems.coursesTaken.remove)
                for (const course of updateItems.coursesTaken.remove)
                    coursesTaken.delete(course);
            userInfo.coursesTaken = Array.from(coursesTaken);
        }
        if (updateItems.interestedSections) {
            if (!userInfo.interestedSections) {
                userInfo.interestedSections = {};
            }
            for (const section in updateItems.interestedSections.add) {
                userInfo.interestedSections[section] =
                    updateItems.interestedSections.add[section];
            }
            if (updateItems.interestedSections.remove)
                for (const section of updateItems.interestedSections.remove)
                    delete userInfo.interestedSections[section];
        }
        if (updateItems.friends) {
            if (updateItems.friends.add) {
                for (const friendId of updateItems.friends.add) {
                    const errorAddingFriend = yield addFriendLocally(friendId, "incoming");
                    if (errorAddingFriend) {
                        return errorAddingFriend;
                    }
                }
            }
            if (updateItems.friends.remove) {
                for (const friendId of updateItems.friends.remove) {
                    yield removeFriendLocally(friendId);
                }
            }
        }
        if (updateItems.friendRequests) {
            if (updateItems.friendRequests.send) {
                for (const friendId of updateItems.friendRequests.send) {
                    const errorCreatingFriendRequest = yield addFriendRequestLocally(friendId, "outgoing");
                    if (errorCreatingFriendRequest) {
                        return errorCreatingFriendRequest;
                    }
                }
            }
            if (updateItems.friendRequests.removeIncoming) {
                for (const friendId of updateItems.friendRequests.removeIncoming) {
                    yield removeFriendRequestLocally(friendId, "incoming");
                }
            }
            if (updateItems.friendRequests.removeOutgoing) {
                for (const friendId of updateItems.friendRequests.removeOutgoing) {
                    yield removeFriendRequestLocally(friendId, "outgoing");
                }
            }
        }
        yield chrome.storage.local.set({
            userInfo: Object.assign({}, userInfo),
        });
        return null;
    });
}
export function deleteAccount() {
    return __awaiter(this, void 0, void 0, function* () {
        const deleteResponse = yield fetchWithAuth(PROD_USER_ENDPOINT, {
            method: "DELETE",
        });
        if (!deleteResponse) {
            return "Unknown error deleting account. Please try again later.";
        }
        if (!deleteResponse.ok) {
            const data = yield deleteResponse.json();
            return `Error deleting account: ${data.message}`;
        }
        yield signOut();
        return null;
    });
}
export function addFriendLocally(friendId_1, friendReqType_1) {
    return __awaiter(this, arguments, void 0, function* (friendId, friendReqType, notificationType = "") {
        const getFriendProfileResponse = yield fetchWithAuth(`${PROD_USER_ENDPOINT}/${friendId}`);
        if (!getFriendProfileResponse) {
            return "Unknown error getting friend profile. Please try again later.";
        }
        const userData = yield getFriendProfileResponse.json();
        if (!getFriendProfileResponse.ok) {
            return `Error getting friend profile: ${userData.message}`;
        }
        yield updateFriendCourseAndSectionIndexes(friendId, userData.coursesTaken, userData.interestedSections);
        const friendProfile = Object.assign({}, userData);
        const currentFriends = (yield chrome.storage.local.get("friends")).friends || {};
        const friendReqsKey = friendReqType === "incoming" ? "friendRequestsIn" : "friendRequestsOut";
        const currentFriendRequests = (yield chrome.storage.local.get(friendReqsKey))[friendReqsKey] || {};
        delete currentFriendRequests[friendId];
        yield chrome.storage.local.set({
            friends: Object.assign(Object.assign({}, currentFriends), { [friendId]: friendProfile }),
            [friendReqsKey]: currentFriendRequests,
        });
        if (notificationType === "FriendRequestAccepted") {
            chrome.notifications.create({
                type: "basic",
                iconUrl: "/images/icon-128.png",
                title: "Friend Request Accepted",
                message: `${friendProfile.name} accepted your friend request.`,
                priority: 2,
            });
        }
        return null;
    });
}
export function updateFriendCourseAndSectionIndexes(friendId, coursesTaken, interestedSections) {
    return __awaiter(this, void 0, void 0, function* () {
        coursesTaken = coursesTaken || [];
        interestedSections = interestedSections || {};
        const friendCoursesTaken = (yield chrome.storage.local.get("friendCoursesTaken")).friendCoursesTaken ||
            {};
        for (const course of coursesTaken) {
            const courseMatch = COURSE_TAKEN_PATTERN.exec(course);
            if (!courseMatch) {
                continue;
            }
            const profName = courseMatch[1];
            const courseCode = (courseMatch[2])
                .substring(0, (courseMatch[2]).indexOf("-"))
                .replace(/\s/g, "");
            if (!courseCode.match(COURSE_CODE_PATTERN))
                continue;
            const curCourseIndex = friendCoursesTaken[courseCode] || {};
            const curProfIndex = friendCoursesTaken[profName] || {};
            curCourseIndex[friendId] = course; // A friend should only have one course entry per course code.
            curProfIndex[friendId] = curProfIndex[friendId] || [];
            curProfIndex[friendId].push(course);
            friendCoursesTaken[courseCode] = curCourseIndex;
            friendCoursesTaken[profName] = curProfIndex;
        }
        const friendInterestedSections = (yield chrome.storage.local.get("friendInterestedSections"))
            .friendInterestedSections || {};
        for (const section in interestedSections) {
            const sectionMatch = INTERESTED_SECTION_PATTERN.exec(section);
            if (!sectionMatch) {
                continue;
            }
            const profName = sectionMatch[1];
            const courseCode = (sectionMatch[2])
                .substring(0, (sectionMatch[2]).indexOf("-"))
                .replace(/\s/g, "");
            const curCourseIndex = friendInterestedSections[courseCode] || {};
            const curProfIndex = friendInterestedSections[profName] || {};
            curCourseIndex[friendId] = section; // A friend should only have one section entry per course code.
            curProfIndex[friendId] = curProfIndex[friendId] || [];
            curProfIndex[friendId].push(section);
            friendInterestedSections[courseCode] = curCourseIndex;
            friendInterestedSections[profName] = curProfIndex;
        }
        yield chrome.storage.local.set({
            friendCoursesTaken,
            friendInterestedSections,
        });
    });
}
export function clearFriendCourseAndSectionIndexes(friendId) {
    return __awaiter(this, void 0, void 0, function* () {
        const friendCoursesTaken = (yield chrome.storage.local.get("friendCoursesTaken")).friendCoursesTaken ||
            {};
        const friendInterestedSections = (yield chrome.storage.local.get("friendInterestedSections"))
            .friendInterestedSections || {};
        for (const courseCode in friendCoursesTaken) {
            if (friendCoursesTaken[courseCode][friendId]) {
                delete friendCoursesTaken[courseCode][friendId];
            }
        }
        for (const profName in friendCoursesTaken) {
            if (friendCoursesTaken[profName][friendId]) {
                delete friendCoursesTaken[profName][friendId];
            }
        }
        for (const courseCode in friendInterestedSections) {
            if (friendInterestedSections[courseCode][friendId]) {
                delete friendInterestedSections[courseCode][friendId];
            }
        }
        for (const profName in friendInterestedSections) {
            if (friendInterestedSections[profName][friendId]) {
                delete friendInterestedSections[profName][friendId];
            }
        }
        yield chrome.storage.local.set({
            friendCoursesTaken,
            friendInterestedSections,
        });
    });
}
export function addFriendRequestLocally(friendId_1, type_1) {
    return __awaiter(this, arguments, void 0, function* (friendId, type, notificationType = "") {
        const getUserPublicProfileResponse = yield fetchWithAuth(`${PROD_USER_ENDPOINT}/${friendId}`);
        if (!getUserPublicProfileResponse) {
            return "Unknown error getting user profile. Please try again later.";
        }
        const userData = yield getUserPublicProfileResponse.json();
        if (!getUserPublicProfileResponse.ok) {
            return `Error getting user profile: ${userData.message}`;
        }
        const friendRequestsKey = type === "incoming" ? "friendRequestsIn" : "friendRequestsOut";
        const existingFriendRequests = (yield chrome.storage.local.get(friendRequestsKey))[friendRequestsKey] ||
            {};
        existingFriendRequests[friendId] = Object.assign({}, userData);
        yield chrome.storage.local.set({
            [friendRequestsKey]: existingFriendRequests,
        });
        if (notificationType === "FriendRequestReceived") {
            console.log("creating chrome notification");
            chrome.notifications.create({
                type: "basic",
                iconUrl: "/images/icon-128.png",
                title: "Friend Request Received",
                message: `${userData.name} sent you a friend request.`,
                priority: 2,
            });
        }
        return null;
    });
}
export function removeFriendLocally(friendId) {
    return __awaiter(this, void 0, void 0, function* () {
        const currentFriends = (yield chrome.storage.local.get("friends")).friends || {};
        delete currentFriends[friendId];
        yield chrome.storage.local.set({ friends: currentFriends });
        yield clearFriendCourseAndSectionIndexes(friendId);
    });
}
export function removeFriendRequestLocally(friendId, type) {
    return __awaiter(this, void 0, void 0, function* () {
        const friendRequestsKey = type === "incoming" ? "friendRequestsIn" : "friendRequestsOut";
        const existingFriendRequests = (yield chrome.storage.local.get(friendRequestsKey))[friendRequestsKey] ||
            {};
        delete existingFriendRequests[friendId];
        yield chrome.storage.local.set({
            [friendRequestsKey]: existingFriendRequests,
        });
    });
}
export function refreshInterestedSections() {
    return __awaiter(this, void 0, void 0, function* () {
        // Check the expiration date of the interestedSections, delete if expired, and also delete from the remote server.
        const userInfo = (yield chrome.storage.local.get("userInfo")).userInfo || {};
        const interestedSections = userInfo.interestedSections || {};
        const sectionsToRemove = [];
        for (const section in interestedSections) {
            const expirationDate = interestedSections[section];
            if (new Date() > new Date(expirationDate)) {
                sectionsToRemove.push(section);
            }
        }
        if (sectionsToRemove.length === 0) {
            return;
        }
        yield updateUser({ interestedSections: { remove: sectionsToRemove } });
    });
}
export function queryUserByName(name) {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetchWithAuth(`${PROD_USER_ENDPOINT}/query?name=${encodeURIComponent(name)}`);
        if (!response) {
            return "Unknown error querying users. Please try again later.";
        }
        const data = yield response.json();
        if (!response.ok) {
            return `Error searching users: ${data.message}`;
        }
        return data;
    });
}
export function importCurrentCourses() {
    return __awaiter(this, void 0, void 0, function* () {
        return yield openTabAndSendMessage(WORKDAY_CURRENT_COURSES_URL, "importCurrentCourses");
    });
}
export function importCourseHistory() {
    return __awaiter(this, void 0, void 0, function* () {
        return yield openTabAndSendMessage(WORKDAY_COURSE_HISTORY_URL, "importCourseHistory");
    });
}
function openTabAndSendMessage(url, message) {
    return __awaiter(this, void 0, void 0, function* () {
        const createdTab = yield chrome.tabs.create({ url });
        function tabListener(tabId, changeInfo, _tab) {
            return __awaiter(this, void 0, void 0, function* () {
                if (tabId === createdTab.id && changeInfo.status === "complete") {
                    try {
                        const response = yield chrome.tabs.sendMessage(createdTab.id, message);
                        chrome.tabs.onUpdated.removeListener(tabListener);
                        return response;
                    }
                    catch (_ignore) {
                        // Ignore the error.
                    }
                }
                return true;
            });
        }
        chrome.tabs.onUpdated.addListener(tabListener);
    });
}
function getS3PhotoUrl(userId) {
    return `https://scu-schedule-helper.s3.amazonaws.com/u%23${userId}/photo`;
}
