var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { fetchWithAuth, signOut } from "./authorization.js";
import { PROD_USER_ENDPOINT, SERVER_PUBLIC_KEY } from "./constants.js";
import { addFriendLocally, refreshUserData, addFriendRequestLocally, removeFriendRequestLocally, removeFriendLocally, clearFriendCourseAndSectionIndexes, updateFriendCourseAndSectionIndexes, } from "./user.js";
const applicationServerKey = urlB64ToUint8Array(SERVER_PUBLIC_KEY);
/**
 * Subscribes the user to push notifications from the production server.
 * @returns {Promise<PushSubscription>}
 */
export function subscribe() {
    return __awaiter(this, void 0, void 0, function* () {
        const existingSubscription = yield self.registration.pushManager.getSubscription();
        if (existingSubscription) {
            return existingSubscription;
        }
        try {
            const subscription = yield self.registration.pushManager.subscribe({
                userVisibleOnly: false,
                applicationServerKey,
            });
            return subscription;
        }
        catch (error) {
            console.error("Subscribe error: ", error);
            return undefined;
        }
    });
}
/**
 * Respond to a notification received from the server.
 * @param {*} notification A JSON notification object received from the server with a notificationType and data field.
 */
export function handleNotification(notification) {
    return __awaiter(this, void 0, void 0, function* () {
        const { notificationType, data } = notification;
        switch (notificationType) {
            case "FriendRequestAccepted":
                yield handleFriendRequestAccepted(data.userId);
                break;
            case "FriendRequestReceived":
                yield addFriendRequestLocally(data.userId, "incoming", "FriendRequestReceived");
                break;
            case "FriendRequestRemoved":
                yield removeFriendRequestLocally(data.userId, data.type);
                break;
            case "FriendRemoved":
                yield removeFriendLocally(data.userId);
                break;
            case "FriendProfileUpdated":
                yield handleFriendProfileUpdated(data.userId);
                break;
            case "FriendRequestProfileUpdated":
                yield addFriendRequestLocally(data.userId, data.type);
                break;
            case "SelfProfileUpdated":
                yield refreshUserData(data.items);
                break;
            case "SelfProfileDeleted":
                yield signOut(true);
                break;
            default:
                break;
        }
    });
}
function handleFriendRequestAccepted(friendId) {
    return __awaiter(this, void 0, void 0, function* () {
        const addFriendError = yield addFriendLocally(friendId, "outgoing", "FriendRequestAccepted");
        if (addFriendError) {
            console.error("Error adding friend: ", addFriendError);
            return;
        }
    });
}
function handleFriendProfileUpdated(friendId) {
    return __awaiter(this, void 0, void 0, function* () {
        const friendProfileResponse = yield fetchWithAuth(`${PROD_USER_ENDPOINT}/${friendId}`);
        if (!friendProfileResponse || !friendProfileResponse.ok) {
            return;
        }
        const friendProfile = yield friendProfileResponse.json();
        const existingFriends = (yield chrome.storage.local.get("friends")).friends || {};
        yield chrome.storage.local.set({
            friends: Object.assign(Object.assign({}, existingFriends), { [friendId]: friendProfile }),
        });
        yield clearFriendCourseAndSectionIndexes(friendId);
        yield updateFriendCourseAndSectionIndexes(friendId, friendProfile.coursesTaken, friendProfile.interestedSections);
        chrome.notifications.create({
            type: "basic",
            iconUrl: "/images/icon-128.png",
            title: "Friend Profile Updated",
            message: `${friendProfile.name} updated their profile.`,
            priority: 2,
        });
    });
}
function urlB64ToUint8Array(base64String) {
    const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
    const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
    const rawData = atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for (let i = 0; i < rawData.length; ++i) {
        outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
}
