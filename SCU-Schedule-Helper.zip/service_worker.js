var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
/// <reference lib="webworker" />
import { getCalendarOAuthToken, signIn, signOut, updateSubscriptionAndRefreshUserData, } from "./utils/authorization.js";
import { PROD_SERVER_URL } from "./utils/constants.js";
import { downloadEvals, downloadProfessorNameMappings, } from "./utils/evalsAndMappings.js";
import { handleNotification, subscribe } from "./utils/notifications.js";
import { getRmpRatings } from "./utils/rmp.js";
import { importCurrentCourses, deleteAccount, importCourseHistory, queryUserByName, refreshInterestedSections, refreshUserData, updateUser, } from "./utils/user.js";
chrome.runtime.onInstalled.addListener((object) => __awaiter(void 0, void 0, void 0, function* () {
    const internalUrl = chrome.runtime.getURL("landing_page/index.html");
    if (object.reason === chrome.runtime.OnInstalledReason.INSTALL) {
        const accessToken = (yield chrome.storage.sync.get("accessToken"))
            .accessToken;
        if (accessToken) {
            const subscription = yield subscribe();
            downloadEvals();
            downloadProfessorNameMappings();
            const refreshError = yield updateSubscriptionAndRefreshUserData(JSON.stringify(subscription));
            if (refreshError) {
                yield signOut();
                chrome.tabs.create({ url: internalUrl }, function (_tab) { });
            }
        }
        else
            chrome.tabs.create({ url: internalUrl }, function (_tab) { });
    }
}));
chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
    if (request.url !== undefined) {
        fetch(request.url)
            .then((response) => response.text())
            .then((data) => sendResponse(data))
            .catch((error) => console.error(error));
    }
    if (request.type === "updateUser") {
        updateUser(request.updateItems, request.allowLocalOnly || false).then((response) => {
            sendResponse(response);
        });
    }
    if (request.type === "getRmpRatings") {
        getRmpRatings(request.profName, false)
            .then((response) => {
            sendResponse(response);
        })
            .catch((error) => {
            console.error("RMP Rating Query Error:", error);
            sendResponse(null);
        });
    }
    if (request.type === "queryUserByName") {
        queryUserByName(request.name).then((response) => {
            sendResponse(response);
        });
    }
    if (request.type === "submitFeedback") {
        handleFeedbackSubmission(request.data).then((response) => {
            sendResponse(response);
        });
    }
    switch (request) {
        case "signIn":
            signIn().then((response) => {
                sendResponse(response);
            });
            break;
        case "signOut":
            signOut().then((response) => {
                sendResponse(response);
            });
            break;
        case "runCalendarOAuth":
            getCalendarOAuthToken().then((response) => {
                sendResponse(response);
            });
            break;
        case "deleteAccount":
            deleteAccount().then((response) => {
                sendResponse(response);
            });
            break;
        case "downloadEvals":
            downloadEvals().then(() => {
                sendResponse();
            });
            break;
        case "importCurrentCourses":
            importCurrentCourses().then((response) => {
                sendResponse(response);
            });
            break;
        case "importCourseHistory":
            importCourseHistory().then((response) => {
                sendResponse(response);
            });
            break;
        case "runStartupChecks":
            runStartupChecks().then(() => {
                sendResponse();
            });
            break;
        default:
            break;
    }
    return true;
});
self.addEventListener("push", function (event) {
    var _a, _b;
    console.log(`Push had this data: "${JSON.stringify((_a = event === null || event === void 0 ? void 0 : event.data) === null || _a === void 0 ? void 0 : _a.json(), null, 2)}"`);
    handleNotification((_b = event === null || event === void 0 ? void 0 : event.data) === null || _b === void 0 ? void 0 : _b.json());
});
self.addEventListener("activate", (_event) => __awaiter(void 0, void 0, void 0, function* () {
    // Set refresh date to 4 days from now.
    yield chrome.storage.local.set({
        refreshSelfDataDate: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).getTime(),
    });
    yield subscribe();
}));
function runStartupChecks() {
    return __awaiter(this, void 0, void 0, function* () {
        const refreshSelfDataDate = (yield chrome.storage.local.get("refreshSelfDataDate")).refreshSelfDataDate;
        if (refreshSelfDataDate === undefined ||
            new Date() > new Date(refreshSelfDataDate)) {
            yield refreshUserData();
            yield chrome.storage.local.set({
                refreshSelfDataDate: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).getTime(),
            });
        }
        // Check if the evals need to be redownloaded.
        yield downloadEvals();
        yield downloadProfessorNameMappings();
        // Check if we need to expire any interestedSections.
        yield refreshInterestedSections();
    });
}
function handleFeedbackSubmission(data) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const response = yield fetch(`${PROD_SERVER_URL}/feedback`, {
                method: "POST",
                body: JSON.stringify(Object.assign({}, data)),
            });
            const responseData = yield response.json();
            return {
                ok: response.ok,
                message: responseData.message,
            };
        }
        catch (error) {
            console.error("Error in handleFeedbackSubmission:", error);
            return {
                ok: false,
                message: "An unknown error occurred. Please try again later.",
            };
        }
    });
}
