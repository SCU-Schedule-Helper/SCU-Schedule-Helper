(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/course_history.tsx-CQ4j8zEC.js")
    );
  })().catch(console.error);

})();
