(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/gcal_integration.tsx-D9lr86iU.js")
    );
  })().catch(console.error);

})();
